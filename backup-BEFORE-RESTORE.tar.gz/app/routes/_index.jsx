import {QuickView} from "~/components/QuickView";
import {useLoaderData, Link} from 'react-router';
import {useState, useEffect} from 'react';
import {Image, Money} from '@shopify/hydrogen';
import {useAside} from '~/components/Aside'; // Adicionado para abrir carrinho
import {useCountdown} from '~/lib/useCountdown'; // ✅ FIX: Importar hook otimizado

export const meta = () => {
  return [
    {title: 'brinqueTEAndo | Brinquedos Educativos e Sensoriais para Autismo e TDAH'},
    {name: 'description', content: 'Loja especializada em brinquedos educativos e sensoriais para crianças com Autismo (TEA) e TDAH. Produtos selecionados para desenvolvimento e inclusão.'},
    {name: 'facebook-domain-verification', content: 'qbk5t5o0agiy90kflze09te3423xgt'},
    {name: 'geo.region', content: 'BR'},
    {name: 'geo.placename', content: 'Brasil'},
    {name: 'keywords', content: 'brinquedos autismo, brinquedos tdah, brinquedos sensoriais, brinquedos educativos, inclusão, desenvolvimento infantil, tea, autismo brasil, brinqueteaando'},
    {httpEquiv: 'content-language', content: 'pt-BR'},
    {property: 'og:title', content: 'brinqueTEAndo | Brinquedos Educativos e Sensoriais'},
    {property: 'og:description', content: 'Loja especializada em brinquedos para Autismo e TDAH. Desenvolvimento com diversão.'},
    {property: 'og:type', content: 'website'},
    {property: 'og:url', content: 'https://brinqueteaando.online'},
    {property: 'og:image', content: 'https://cdn.shopify.com/s/files/1/0778/2921/0327/files/5.avif?v=1765596668'},
    {property: 'og:image:width', content: '1200'},
    {property: 'og:image:height', content: '630'},
    {property: 'og:site_name', content: 'brinqueTEAndo'},
    {property: 'og:locale', content: 'pt_BR'},
    {name: 'twitter:card', content: 'summary_large_image'},
    {name: 'twitter:title', content: 'brinqueTEAndo | Brinquedos Educativos e Sensoriais'},
    {name: 'twitter:description', content: 'Brinquedos selecionados para desenvolvimento de crianças com TEA e TDAH.'},
    {name: 'twitter:image', content: 'https://cdn.shopify.com/s/files/1/0778/2921/0327/files/5.avif?v=1765596668'},
    {name: 'robots', content: 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1'},
    {name: 'googlebot', content: 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1'},
    {name: 'viewport', content: 'width=device-width, initial-scale=1, maximum-scale=5'},
    {name: 'mobile-web-app-capable', content: 'yes'},
    {name: 'apple-mobile-web-app-capable', content: 'yes'},
    {name: 'theme-color', content: '#87CEEB'},
    {tagName: 'link', rel: 'canonical', href: 'https://brinqueteaando.online'},
    {tagName: 'link', rel: 'alternate', hreflang: 'pt-br', href: 'https://brinqueteaando.online'},
    {tagName: 'link', rel: 'alternate', hreflang: 'x-default', href: 'https://brinqueteaando.online'},
    {tagName: 'link', rel: 'preconnect', href: 'https://cdn.shopify.com'},
    {tagName: 'link', rel: 'dns-prefetch', href: 'https://cdn.shopify.com'},
    {tagName: 'link', rel: 'preload', as: 'video', href: 'https://cdn.shopify.com/videos/c/o/v/9788927ebacf4e3ca19449cafd11fc55.mp4'},
  ];
};

export async function loader({context}) {
  const {storefront} = context;
  const {collections} = await storefront.query(FEATURED_COLLECTIONS_QUERY);
  const {products} = await storefront.query(FEATURED_PRODUCTS_QUERY);
  
  // Footer Menu Manual
  const footerMenu = {
    id: 'custom-footer-manual',
    items: [
      {
        id: 'group-1',
        title: '🧸 BrinqueTEAndo',
        items: [
          { id: 'l1', title: 'Quem é Margareth Almeida', url: '/pages/quem-e-margareth-almeida' },
          { id: 'l2', title: 'Leve a BrinqueTEAndo até Você', url: '/pages/leve-a-brinqueteando-ate-voce' },
          { id: 'l3', title: 'Seja Revendedor BrinqueTEAndo', url: '/pages/seja-revendedor-brinqueteando' },
          { id: 'l4', title: 'Guias práticos', url: '/pages/guias-praticos' },
        ]
      },
      {
        id: 'group-2',
        title: '💡 Conteúdos',
        items: [
          { id: 'l5', title: 'Como escolher brinquedos', url: '/pages/como-escolher-brinquedos' },
          { id: 'l6', title: 'Dicas para TDAH e TEA', url: '/pages/dicas-para-tdah-e-tea' },
          { id: 'l7', title: 'FAQ', url: '/pages/faq' },
        ]
      },
      {
        id: 'group-3',
        title: '📦 Ajuda',
        items: [
          { id: 'l8', title: 'Contact', url: '/pages/contact' },
          { id: 'l9', title: 'Política de Envio', url: '/pages/politica-de-envio' },
          { id: 'l10', title: 'Política de Devolução', url: '/pages/politica-de-devolucao' },
        ]
      },
      {
        id: 'group-4',
        title: '🔒 Legal',
        items: [
          { id: 'l11', title: 'Política de Privacidade', url: '/policies/politica-de-privacidade' },
          { id: 'l12', title: 'Política de Cookies', url: '/policies/politica-de-cookies' },
          { id: 'l13', title: 'Aviso Legal', url: '/pages/aviso-legal' },
        ]
      }
    ]
  };

  const {cart} = context; // Adicionado para exibir contador do carrinho

  return {collections, products, footerMenu, cart: cart.get()};
}

export default function Homepage() {
  const {collections, products, footerMenu, cart} = useLoaderData();
  const [currentPromo, setCurrentPromo] = useState(0);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [quickViewProduct, setQuickViewProduct] = useState(null);

  // ✅ FIX: Usar hook useCountdown otimizado com requestAnimationFrame
  const {timeLeft, isMounted} = useCountdown();

  const {open} = useAside(); // Hook para abrir o carrinho

  // Ahrefs Analytics Script
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://analytics.ahrefs.com/analytics.js';
    script.async = true;
    script.setAttribute('data-key', 'ffWKXpflS652BvLv6vtybg');
    document.body.appendChild(script);
    return () => {};
  }, []);

  const schemaOrgJSON = [
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "brinqueTEAndo",
      "url": "https://brinqueteaando.online",
      "logo": "https://cdn.shopify.com/s/files/1/0778/2921/0327/files/5.avif?v=1765596668",
      "description": "Loja especializada em brinquedos sensoriais e educativos para crianças com Autismo e TDAH.",
      "contactPoint": { "@type": "ContactPoint", "telephone": "+55-13-99189-9708", "contactType": "Customer Service", "areaServed": ["BR"], "availableLanguage": ["Portuguese"] }
    },
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "brinqueTEAndo",
      "url": "https://brinqueteaando.online",
      "potentialAction": { "@type": "SearchAction", "target": "https://brinqueteaando.online/search?q={search_term_string}", "query-input": "required name=search_term_string" }
    }
  ];

  const promoMessages = [
    "🚚 Frete grátis para toda Baixada Santista!",
    "⭐ brinqueTEAando REWARDS — Ganhe pontos!",
    "🎁 Trocas e devoluções facilitadas",
    "🧠 Desenvolvimento e diversão para TEA e TDAH",
    "💎 Qualidade e Segurança garantidas",
    "🎅 Use o código BEMVINDO10 e ganhe 10% OFF"
  ];

  const testimonials = [
    {name: "Sarah L.", text: "Meu filho adorou os brinquedos! Ajudou muito na concentração.", rating: 5, image: "https://cdn.shopify.com/s/files/1/0778/2921/0327/files/1.jpg?v=1765938975"},
    {name: "Michael R.", text: "Excelente qualidade e entrega rápida. Recomendo para pais atípicos.", rating: 5, image: "https://cdn.shopify.com/s/files/1/0778/2921/0327/files/2.jpg?v=1765938975"},
    {name: "James T.", text: "Atendimento nota 10. A equipe entende nossas necessidades.", rating: 5, image: "https://cdn.shopify.com/s/files/1/0778/2921/0327/files/4.jpg?v=1765938975"},
    {name: "Emily K.", text: "Produtos maravilhosos, meu sobrinho não larga o pop-it.", rating: 5, image: "https://cdn.shopify.com/s/files/1/0778/2921/0327/files/3.jpg?v=1765938975"}
  ];

  // ✅ FIX: Removido calculateHolidayCountdown - usando hook useCountdown agora

  useEffect(() => {
    const promoTimer = setInterval(() => setCurrentPromo((p) => (p + 1) % promoMessages.length), 4000);
    return () => clearInterval(promoTimer);
  }, []);

  useEffect(() => {
    const testimonialTimer = setInterval(() => setCurrentTestimonial((p) => (p + 1) % testimonials.length), 5000);
    return () => clearInterval(testimonialTimer);
  }, []);

  // FORCE VIDEO AUTOPLAY ON MOBILE - RESPECT ACCESSIBILITY
  useEffect(() => {
    if (typeof document !== 'undefined') {
      if (document.documentElement.classList.contains('neurodivergent')) return;
    }
    const video = document.getElementById('hero-video');
    if (video) {
      const playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise.catch(err => {
          const forcePlay = () => {
            if (!document.documentElement.classList.contains('neurodivergent')) {
              video.play();
            }
            document.removeEventListener('touchstart', forcePlay);
            document.removeEventListener('click', forcePlay);
            document.removeEventListener('scroll', forcePlay);
          };
          document.addEventListener('touchstart', forcePlay, { once: true });
          document.addEventListener('click', forcePlay, { once: true });
          document.addEventListener('scroll', forcePlay, { once: true });
        });
      }
      setTimeout(() => {
        if (!document.documentElement.classList.contains('neurodivergent')) {
          video.play().catch(() => {});
        }
      }, 100);
    }
  }, []);

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(schemaOrgJSON)}} />
      
      <style>{`
        header { display: none !important; }
        [class*="Header"] { display: none !important; }
        div[data-testid="header"] { display: none !important; }
        nav[data-testid="header-nav"] { display: none !important; }
        
        * { box-sizing: border-box; }
        body, html {
          overflow-x: hidden !important;
          width: 100% !important;
          margin: 0 !important;
          padding: 0 !important;
        }
        main {
          width: 100% !important;
          max-width: 100% !important;
          overflow-x: hidden !important;
          margin: 0 !important;
          padding: 0 !important;
        }
        @keyframes marquee-christmas {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee-christmas {
          display: flex;
          width: fit-content;
          animation: marquee-christmas 60s linear infinite;
        }
        .animate-marquee-christmas:hover {
          animation-play-state: paused;
        }
      `}</style>

      <main role="main" aria-label="brinqueTEAando - Brinquedos Educativos e Sensoriais" className="bg-[#FEFDF8] flex flex-col min-h-screen w-full overflow-x-hidden">
        <div className="flex-grow w-full">
          
          {/* Top Bar with Countdown */}
          <div className="bg-[#3A8ECD] text-white py-3 text-center w-full">
            <div className="max-w-7xl mx-auto px-4 flex items-center justify-center gap-4 flex-wrap">
              <span className="text-sm md:text-base font-bold tracking-wide">
                {timeLeft.holiday?.emoji} {timeLeft.holiday?.message} {timeLeft.holiday?.emoji}
              </span>
              <div className="flex items-center gap-2 border-2 border-white px-4 py-1 bg-white/20">
                <span className="text-2xl font-bold">{String(timeLeft.days).padStart(2, '0')}</span><span className="text-xs">D</span>
                <span className="text-2xl font-bold">{String(timeLeft.hours).padStart(2, '0')}</span><span className="text-xs">H</span>
                <span className="text-2xl font-bold">{String(timeLeft.minutes).padStart(2, '0')}</span><span className="text-xs">M</span>
                <span className="text-2xl font-bold">{String(timeLeft.seconds).padStart(2, '0')}</span><span className="text-xs">S</span>
              </div>
            </div>
          </div>

          {/* Marquee Bar */}
          <div className="w-full bg-[#3A8ECD] border-y-2 border-[#FB8A38] overflow-hidden py-3 relative z-20 shadow-lg">
            <div className="absolute inset-0 pointer-events-none opacity-10" style={{backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '15px 15px'}}></div>
            <div className="animate-marquee-christmas flex items-center">
              {[...Array(12)].map((_, i) => (
                <div key={i} className="flex items-center mx-8 whitespace-nowrap">
                  <span className="text-2xl mr-3 filter drop-shadow-md">🎭</span>
                  <span className="text-[#FEFDF8] font-serif italic text-xl tracking-widest font-medium uppercase drop-shadow-md" style={{textShadow: '0 1px 2px rgba(0,0,0,0.5)'}}>
                     🧩 III Jornada Autismo Baixada Santista - 29/03 em Santos! 🎪 ExpoTEA 2025 em Novembro - SP!
                  </span>
                  <span className="text-2xl ml-3 filter drop-shadow-md">🎪</span>
                  <div className="ml-8 flex items-center gap-2 opacity-70">
                    <span className="text-[#FB8A38] text-xs">✦</span>
                    <span className="w-16 h-[1px] bg-[#FB8A38]"></span>
                    <span className="text-[#FB8A38] text-xs">✦</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Coupons Section */}
          <div className="bg-gradient-to-r from-[#3A8ECD] via-[#FB8A38] to-[#82CBB7] py-12 px-6 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10" style={{backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,.1) 10px, rgba(255,255,255,.1) 20px)'}}></div>
            <div className="relative z-10 max-w-7xl mx-auto">
              <h2 className="text-white text-3xl md:text-4xl font-light mb-8 tracking-wide text-center">🎁 Cupons Especiais BrinqueTEAando</h2>
              <div className="grid md:grid-cols-3 gap-6 mb-6">
                <div className="bg-white/95 backdrop-blur-sm rounded-lg p-6 text-center shadow-lg">
                  <div className="text-4xl mb-4">🎯</div>
                  <h3 className="text-[#3A8ECD] text-xl font-bold mb-2">PRIMEIRA COMPRA</h3>
                  <p className="text-gray-700 text-lg font-mono font-bold mb-2">BEMVINDO10</p>
                  <p className="text-gray-600 text-sm">10% OFF na primeira compra</p>
                </div>
                <div className="bg-white/95 backdrop-blur-sm rounded-lg p-6 text-center shadow-lg">
                  <div className="text-4xl mb-4">⭐</div>
                  <h3 className="text-[#FB8A38] text-xl font-bold mb-2">TEA</h3>
                  <p className="text-gray-700 text-lg font-mono font-bold mb-2">TEA15</p>
                  <p className="text-gray-600 text-sm">15% OFF garanta ja o seu</p>
                </div>
                <div className="bg-white/95 backdrop-blur-sm rounded-lg p-6 text-center shadow-lg">
                  <div className="text-4xl mb-4">🚚</div>
                  <h3 className="text-[#FBA25C] text-xl font-bold mb-2">TDAH AUTISMO</h3>
                  <p className="text-gray-700 text-lg font-mono font-bold mb-2">TEA20</p>
                  <p className="text-gray-600 text-sm">Aproveite esse Desconto Imperdivel</p>
                </div>
              </div>
              <p className="text-white/90 text-center text-sm">Use os códigos no checkout para aplicar os descontos</p>
            </div>
          </div>

          {/* Promo Ticker */}
          <div className="bg-[#FB8A38] text-white py-3 overflow-hidden relative w-full">
            <div className="max-w-7xl mx-auto px-6">
              <div className="relative h-6 flex items-center justify-center">
                {promoMessages.map((msg, idx) => (
                  <div key={idx} className={`absolute inset-0 flex items-center justify-center transition-all duration-1000 ${idx === currentPromo ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-full'}`}>
                    <p className="text-sm md:text-base font-semibold tracking-wide text-center px-4">{msg}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Trust Indicators */}
          <div className="bg-[#F5F3ED] border-b border-[#D4AF69] w-full">
            <div className="max-w-7xl mx-auto px-6 py-4">
              <div className="flex items-center justify-center gap-2 mb-3">
                <span className="text-xl font-serif text-[#0A3D2F]">🎁 COMPRE COM CONFIANÇA:</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
                <div className="flex items-start justify-center md:justify-start gap-3">
                  <div>
                    <p className="text-[#0A3D2F] font-semibold mb-1"><span className="text-[#b87333]">Entrega</span> Garantida</p>
                    <p className="text-sm text-[#9d8b7c]">Envio rápido e seguro para todo o Brasil. <span className="underline cursor-pointer"></span></p>
                  </div>
                </div>
                <div className="flex items-start justify-center gap-3">
                  <div>
                    <p className="text-[#0A3D2F] font-semibold mb-1"><span className="text-[#b87333]">Cuidado</span> em Cada Etapa</p>
                    <p className="text-sm text-[#9d8b7c]">Atendimento humanizado, suporte próximo e troca facilitada. <span className="underline cursor-pointer"></span></p>
                  </div>
                </div>
                <div className="flex items-start justify-center md:justify-end gap-3">
                  <div>
                    <p className="text-[#0A3D2F] font-semibold mb-1"><span className="text-[#b87333]">Compra</span> Segura e Confiável</p>
                    <p className="text-sm text-[#9d8b7c]">Ambiente protegido, pagamento seguro e total transparência. <span className="underline cursor-pointer"></span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Main Navigation - ORGANIZADA E COM LOGO NOVA */}
          <nav className="bg-white shadow-sm sticky top-0 z-50 w-full border-b-4 border-[#3A8ECD]">
            <div className="max-w-7xl mx-auto px-3 py-3 sm:px-6 sm:py-4">
              <div className="flex items-center justify-between gap-2 sm:gap-4">
                
                {/* LOGO */}
                <Link to="/" className="flex items-center group flex-shrink-0">
                    <img 
                      src="https://cdn.shopify.com/s/files/1/0973/7116/0942/files/ChatGPT_Image_Jan_5__2026__01_21_24_PM-removebg-preview_96f44aed-45b5-43f6-86b1-9b1039d9e94b.png?v=1769926918" 
                      alt="brinqueTEAando" 
                      className="h-20 sm:h-24 md:h-32 w-auto object-contain transition-transform duration-300 group-hover:scale-105"
                    />
                </Link>

                {/* Desktop Menu - Organizado e com espaçamento */}
                <div className="hidden lg:flex items-center gap-6 flex-1 justify-center">
                  {[
                    {name: 'INÍCIO', href: '/'},
                    {name: 'Brinquedos Terapêuticos', href: '/collections/brinquedos-terapeuticos'},
                    {name: 'Por Necessidade', href: '/collections/por-necessidade'},
                    {name: 'Por Idade', href: '/collections/por-idade'},
                    {name: 'Ambiente & Rotina', href: '/collections/ambiente-rotina'},
                    {name: 'Apoio aos Pais', href: '/collections/apoio-aos-pais'},
                    {name: 'CONTATO', href: '/pages/contact'}
                  ].map(item => (
                    <Link key={item.name} to={item.href} className="text-[#3A8ECD] font-bold text-sm hover:text-[#FB8A38] hover:underline decoration-2 underline-offset-4 transition-all uppercase tracking-wide whitespace-nowrap">
                      {item.name}
                    </Link>
                  ))}
                </div>

                {/* Cart & Mobile Toggle */}
                <div className="flex items-center gap-4">
                  <Link to="/account" className="text-[#3A8ECD] hover:text-[#FB8A38] text-[10px] sm:text-xs font-medium whitespace-nowrap transition-colors px-1 sm:px-2">Entrar</Link>
                  <button onClick={() => open('cart')} className="relative group">
                      <span className="text-2xl">🛒</span>
                      <span className="absolute -top-2 -right-2 bg-[#FB8A38] text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white group-hover:scale-110 transition-transform">
                        {cart?.totalQuantity || 0}
                      </span>
                  </button>
                  <button onClick={() => { const menu = document.getElementById('mobile-menu'); menu.classList.toggle('hidden'); }} className="lg:hidden text-[#3A8ECD] p-2" aria-label="Toggle menu">
                    <span className="text-2xl">☰</span>
                  </button>
                </div>
              </div>

              {/* Mobile Menu */}
              <div id="mobile-menu" className="hidden lg:hidden bg-white border-t border-gray-100 absolute w-full left-0 shadow-xl z-50">
                <div className="flex flex-col p-4">
                  {[
                    {name: 'INÍCIO', href: '/'},
                    {name: 'Brinquedos Terapêuticos', href: '/collections/brinquedos-terapeuticos'},
                    {name: 'Por Necessidade', href: '/collections/por-necessidade'},
                    {name: 'Por Idade', href: '/collections/por-idade'},
                    {name: 'Ambiente & Rotina', href: '/collections/ambiente-rotina'},
                    {name: 'Apoio aos Pais', href: '/collections/apoio-aos-pais'},
                    {name: 'CONTATO', href: '/pages/contact'}
                  ].map(item => (
                    <Link key={item.name} to={item.href} className="text-[#3A8ECD] text-sm font-semibold tracking-wide hover:text-[#FB8A38] transition-colors py-2 border-b border-gray-200 uppercase" onClick={() => { const menu = document.getElementById('mobile-menu'); menu.classList.add('hidden'); }}>
                      {item.name}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </nav>

          <div className="bg-[#3A8ECD] text-white py-3 w-full">
            <div className="max-w-7xl mx-auto px-4 text-center">
              <p className="text-sm font-medium tracking-wider">🚚 Frete grátis para Praia Grande, São Vicente e Santos • Envio rápido • Compra segura 🎉</p>
            </div>
          </div>

          {/* Hero Video */}
          <section className="mb-12 sm:mb-16 md:mb-20 w-full px-0">
            <div className="max-w-7xl mx-auto mt-4 sm:mt-8 px-2 sm:px-4 md:px-6 w-full">
              <div className="relative h-64 sm:h-80 md:h-96 lg:h-[70vh] overflow-hidden rounded-[10px] shadow-xl sm:shadow-2xl">
                <video id="hero-video" autoPlay loop muted playsInline webkit-playsinline="true" x-webkit-airplay="allow" preload="auto" className="absolute inset-0 w-full h-full object-cover" poster="https://cdn.shopify.com/s/files/1/0973/7116/0942/files/002.jpg?v=1769385748">
                  <source src="https://cdn.shopify.com/videos/c/o/v/288d4004873043ffb9ba58d24ba5a38c.mp4" type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
                <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/20 z-10"></div>
                <div className="absolute inset-0 z-20 flex flex-col justify-center px-6 sm:px-8 md:px-16">
                  <h1 className="text-white text-2xl sm:text-4xl md:text-6xl font-light tracking-widest mb-2 sm:mb-4"></h1>
                  <p className="text-[#FB8A38] text-sm sm:text-lg md:text-xl tracking-wider mb-2 sm:mb-4">Brinquedos Educativos e Sensoriais para TEA e TDAH</p>
                  <Link to="/collections/all" className="inline-block border-2 border-[#FB8A38] bg-[#3A8ECD] text-white px-6 sm:px-10 py-2 sm:py-3 rounded-full hover:bg-[#FB8A38] hover:text-white hover:border-[#FB8A38] transition-all font-semibold tracking-wider w-fit mt-2 sm:mt-4 text-xs sm:text-base">EXPLORAR PRODUTOS</Link>
                </div>
              </div>
            </div>
          </section>

          {/* Sections */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 md:px-12 mb-20 w-full">
            <div className="grid md:grid-cols-2 gap-6 sm:gap-8">
              <div className="relative h-72 sm:h-80 md:h-96 overflow-hidden rounded-[10px] shadow-xl group">
                <img src="https://cdn.shopify.com/s/files/1/0973/7116/0942/files/banner_1.png?v=1769878997" alt="Brinquedos Terapêuticos" className="w-full h-full object-cover group-hover:scale-110 transition-all duration-700" width="800" height="600"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#b91c1c]/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-6 sm:bottom-8 left-6 sm:left-8 right-6 sm:right-8 text-white">
                  <h2 className="text-2xl sm:text-3xl font-light mb-2 tracking-wide">🧸 Brinquedos Terapêuticos</h2>
                  <p className="text-[#D4AF69] mb-4 text-sm sm:text-base">Estimule brincando</p>
                  <Link to="/collections/brinquedos-terapeuticos" className="inline-block bg-white text-[#b91c1c] px-6 sm:px-8 py-2 sm:py-3 rounded-full font-semibold hover:bg-[#D4AF69] hover:text-white transition-all text-sm sm:text-base">SHOP NOW</Link>
                </div>
              </div>
              <div className="relative h-72 sm:h-80 md:h-96 overflow-hidden rounded-[10px] shadow-xl group">
                <img src="https://cdn.shopify.com/s/files/1/0973/7116/0942/files/banner_2.png?v=1769878999" alt="Ambiente & Rotina" className="w-full h-full object-cover group-hover:scale-110 transition-all duration-700" width="800" height="600"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A3D2F]/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-6 sm:bottom-8 left-6 sm:left-8 right-6 sm:right-8 text-white">
                  <h2 className="text-2xl sm:text-3xl font-light mb-2 tracking-wide">💡 Ambiente & Rotina</h2>
                  <p className="text-[#D4AF69] mb-4 text-sm sm:text-base">Onde a rotina vira apoio</p>
                  <Link to="/collections/ambiente-rotina" className="inline-block bg-white text-[#0A3D2F] px-6 sm:px-8 py-2 sm:py-3 rounded-full font-semibold hover:bg-[#D4AF69] hover:text-white transition-all text-sm sm:text-base">SHOP NOW</Link>
                </div>
              </div>
            </div>
          </section>

          {/* Habilidades */}
          <section className="bg-gradient-to-br from-blue-50 to-orange-50 py-16 sm:py-20 mb-20 w-full">
            <div className="max-w-7xl mx-auto px-4 sm:px-6">
              <h2 className="text-[#0A3D2F] text-2xl sm:text-3xl md:text-4xl font-light text-center mb-4 sm:mb-6 tracking-wide">Encontre o Brinquedo Ideal por Habilidade</h2>
              <p className="text-[#9d8b7c] text-center mb-8 sm:mb-12 text-sm sm:text-base">Desenvolvimento terapêutico através da brincadeira</p>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6">
                {[
                  {emoji: '🎯', title: 'COORDENAÇÃO', url: '/collections/all?tag=Coordenação+Motora', bgColor: 'bg-[#3A8ECD]'},
                  {emoji: '🧩', title: 'CONCENTRAÇÃO', url: '/collections/all?tag=Concentração+e+Foco', bgColor: 'bg-[#FB8A38]'},
                  {emoji: '🤲', title: 'SENSORIAL', url: '/collections/all?tag=Desenvolvimento+Sensorial', bgColor: 'bg-[#FBA25C]'},
                  {emoji: '🎨', title: 'CRIATIVIDADE', url: '/collections/all?tag=Criatividade', bgColor: 'bg-[#3A8ECD]'},
                  {emoji: '👥', title: 'SOCIAL', url: '/collections/all?tag=Habilidades+Sociais', bgColor: 'bg-[#FB8A38]'},
                  {emoji: '💬', title: 'LINGUAGEM', url: '/collections/all?tag=Linguagem+e+Comunicação', bgColor: 'bg-[#FBA25C]'}
                ].map((item, idx) => (
                  <Link key={idx} to={item.url} className="group" aria-label={`Encontrar brinquedos para ${item.title}`}>
                    <div className={`${item.bgColor} text-white p-8 rounded-2xl transition-all duration-300 hover:scale-105 hover:shadow-xl flex flex-col items-center justify-center h-full text-center`}>
                      <div className="text-4xl sm:text-5xl mb-3">{item.emoji}</div>
                      <h3 className="text-base sm:text-lg font-bold leading-tight">{item.title}</h3>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>

          {/* SEJA UM REVENDEDOR - NOVA SEÇÃO */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 mb-20 w-full">
            <div className="bg-gradient-to-r from-[#3A8ECD] to-[#FB8A38] rounded-[10px] shadow-2xl overflow-hidden">
              <div className="grid md:grid-cols-2 gap-0">
                <div className="bg-gradient-to-br from-[#3A8ECD] to-[#2874A6] p-8 sm:p-12 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#FB8A38] via-[#FEFDF8] to-[#82CBB7]"></div>
                  <div className="absolute bottom-0 right-0 w-full h-1 bg-gradient-to-l from-[#FB8A38] via-[#FEFDF8] to-[#82CBB7]"></div>
                  <div className="relative z-10 w-full max-w-[340px] sm:max-w-[400px]">
                    <div className="bg-white rounded-xl p-6 sm:p-8 shadow-2xl border-4 border-[#FB8A38]">
                      <div className="text-center mb-6">
                        <div className="text-6xl mb-4">🤝</div>
                        <h3 className="text-[#3A8ECD] text-2xl sm:text-3xl font-bold tracking-wide mb-2">Seja Parceiro</h3>
                        <p className="text-gray-600 text-sm">Programa de Revendedores</p>
                      </div>
                      <div className="space-y-4">
                        <div className="flex items-center gap-3 bg-[#3A8ECD]/10 p-3 rounded-lg">
                          <span className="text-2xl">💰</span>
                          <div>
                            <p className="text-[#3A8ECD] font-bold text-sm">Até 35% de Comissão</p>
                            <p className="text-gray-600 text-xs">Lucratividade garantida</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 bg-[#FB8A38]/10 p-3 rounded-lg">
                          <span className="text-2xl">📦</span>
                          <div>
                            <p className="text-[#FB8A38] font-bold text-sm">Suporte Completo</p>
                            <p className="text-gray-600 text-xs">Material e treinamento</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 bg-[#82CBB7]/10 p-3 rounded-lg">
                          <span className="text-2xl">🎯</span>
                          <div>
                            <p className="text-[#82CBB7] font-bold text-sm">Sem Investimento Inicial</p>
                            <p className="text-gray-600 text-xs">Comece agora mesmo</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-8 sm:p-12 flex flex-col justify-center bg-gradient-to-br from-[#FB8A38] to-[#FBA25C]">
                  <div className="inline-block bg-white text-[#3A8ECD] px-4 py-1 rounded-full text-xs font-bold mb-4 w-fit">OPORTUNIDADE DE NEGÓCIO</div>
                  <h2 className="text-white text-3xl sm:text-4xl md:text-5xl font-light mb-4 sm:mb-6 tracking-wide">Revenda <span className="text-[#0A3D2F] font-semibold">brinqueTEAndo</span></h2>
                  <p className="text-white text-lg sm:text-xl mb-4 sm:mb-6">Ajude famílias e gere renda com brinquedos terapêuticos</p>
                  
                  <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 mb-6">
                    <h3 className="text-white font-bold mb-3 text-lg">✨ Benefícios Exclusivos:</h3>
                    <ul className="space-y-2 text-white text-sm">
                      <li className="flex items-start gap-2">
                        <span className="text-[#0A3D2F] font-bold">✓</span>
                        <span><strong>Comissões atrativas</strong> em cada venda</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-[#0A3D2F] font-bold">✓</span>
                        <span><strong>Material de divulgação</strong> profissional</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-[#0A3D2F] font-bold">✓</span>
                        <span><strong>Treinamento completo</strong> sobre os produtos</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-[#0A3D2F] font-bold">✓</span>
                        <span><strong>Suporte dedicado</strong> para revendedores</span>
                      </li>
                    </ul>
                  </div>

                  <Link to="/pages/seja-revendedor-brinqueteando" className="bg-white text-[#3A8ECD] px-6 sm:px-8 py-3 sm:py-4 rounded-full font-semibold hover:bg-[#0A3D2F] hover:text-white hover:scale-105 transition-all text-center w-fit text-sm sm:text-base shadow-lg">QUERO SER REVENDEDOR</Link>
                  <p className="text-xs text-white/80 mt-3">🎁 Faça parte da nossa rede de parceiros</p>
                </div>
              </div>
            </div>
          </section>

          {/* Testimonials */}
          <section className="bg-white py-12 sm:py-20 mb-20 w-full">
            <div className="max-w-7xl mx-auto px-4 sm:px-6">
              <h2 className="text-[#0A3D2F] text-2xl sm:text-3xl md:text-4xl font-light text-center mb-4 tracking-wide">A Opinião de Quem já Comprou com a Gente</h2>
              <p className="text-[#9d8b7c] text-center mb-8 sm:mb-12 text-sm sm:text-base">Mais de 3.498 famílias transformando o aprendizado em diversão</p>
              <div className="relative h-auto min-h-[250px] sm:min-h-[280px]">
                {testimonials.map((testimonial, idx) => (
                  <div key={idx} className={`absolute inset-0 transition-all duration-1000 ${idx === currentTestimonial ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
                    <div className="bg-[#FEFDF8] rounded-[10px] shadow-xl p-6 sm:p-8 max-w-3xl mx-auto">
                      <div className="flex items-center gap-3 sm:gap-4 mb-4 sm:mb-6">
                        <img src={testimonial.image} alt={`${testimonial.name} - Cliente brinqueTEAando feliz`} className="w-12 h-12 sm:w-16 sm:h-16 rounded-full object-cover border-2 border-[#D4AF69]" width="64" height="64"/>
                        <div>
                          <p className="font-semibold text-[#0A3D2F] text-sm sm:text-base">{testimonial.name}</p>
                          <div className="flex gap-1">
                            {[...Array(testimonial.rating)].map((_, i) => (
                              <svg key={i} className="w-4 h-4 sm:w-5 sm:h-5 text-[#D4AF69]" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                            ))}
                          </div>
                        </div>
                      </div>
                      <p className="text-[#2a2a2a] text-base sm:text-lg italic leading-relaxed">"{testimonial.text}"</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-center gap-2 mt-6 sm:mt-8">
                {testimonials.map((_, idx) => (
                  <button key={idx} onClick={() => setCurrentTestimonial(idx)} className={`h-2 rounded-full transition-all ${idx === currentTestimonial ? 'bg-[#D4AF69] w-8' : 'bg-[#9d8b7c]/30 w-2'}`} aria-label={`View testimonial ${idx + 1}`}/>
                ))}
              </div>
            </div>
          </section>

          {/* Envio */}
          <section className="bg-gradient-to-b from-white to-[#FEFDF8] py-16 sm:py-20 mb-20 w-full">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 w-full">
              <h2 className="text-[#3A8ECD] text-2xl sm:text-3xl md:text-4xl font-light text-center mb-4 tracking-wide">Brinquedos Educativos Entregues em Todo o Brasil</h2>
              <p className="text-gray-600 text-center mb-12 text-sm sm:text-base mx-auto max-w-3xl">
                Especializados em desenvolvimento sensorial e cognitivo para crianças com TEA e TDAH. Entregamos com carinho e cuidado em todo o território nacional.
              </p>
              <div className="mb-12">
                <div className="bg-gradient-to-r from-[#3A8ECD] via-[#FB8A38] to-[#FBA25C] rounded-xl p-8 shadow-xl border-4 border-[#FB8A38] relative overflow-hidden">
                  <div className="absolute top-0 right-0 text-8xl opacity-10">🎁</div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-center gap-3 mb-4">
                      <span className="text-5xl">🏖️</span>
                      <div className="text-center">
                        <div className="inline-block bg-white/90 text-[#FB8A38] px-4 py-1 rounded-full text-xs font-bold mb-2 uppercase tracking-wider">FRETE 100% GRÁTIS</div>
                        <h3 className="text-white text-2xl sm:text-3xl font-bold mb-2">Baixada Santista</h3>
                      </div>
                      <span className="text-5xl">🌊</span>
                    </div>
                    <p className="text-white text-center text-lg mb-4 font-medium">Para as famílias da região, oferecemos <span className="font-bold text-xl">FRETE GRÁTIS</span> em todos os pedidos!</p>
                    <div className="bg-white/95 rounded-lg p-4 mt-4">
                      <p className="text-[#3A8ECD] font-semibold text-center mb-3 text-sm uppercase tracking-wide">Cidades Atendidas:</p>
                      <div className="flex flex-wrap justify-center gap-3">
                        {['Santos', 'São Vicente', 'Praia Grande'].map((city, idx) => (
                          <span key={idx} className="bg-[#3A8ECD] text-white px-4 py-2 rounded-full text-sm font-medium">{city}</span>
                        ))}
                      </div>
                      <p className="text-gray-700 text-sm text-center mt-4">Brinquedos selecionados para estimulação sensorial, desenvolvimento da comunicação e habilidades sociais de crianças neurodivergentes.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-shadow border-l-4 border-[#3A8ECD]">
                  <div className="text-4xl mb-4 text-center">🏙️</div>
                  <h3 className="text-xl font-semibold text-[#3A8ECD] mb-3 text-center">Grande São Paulo</h3>
                  <p className="text-gray-600 text-sm leading-relaxed text-center">Envio rápido para famílias da capital e região metropolitana. Brinquedos terapêuticos para desenvolvimento de habilidades em crianças com Autismo e TDAH.</p>
                </div>
                <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-shadow border-l-4 border-[#FB8A38]">
                  <div className="text-4xl mb-4 text-center">🌆</div>
                  <h3 className="text-xl font-semibold text-[#FB8A38] mb-3 text-center">Todo o Brasil</h3>
                  <p className="text-gray-600 text-sm leading-relaxed text-center mb-3">Atendemos todas as regiões com produtos educativos e sensoriais. Frete grátis para Baixada Santista. Especializados em brinquedos para TEA.</p>
                  <div className="bg-gradient-to-r from-[#3A8ECD] to-[#FBA25C] rounded-lg p-3 mt-4">
                    <p className="text-white text-center text-sm font-medium">Conhece seu filho melhor do que ninguém? 💙 Então escolha brinquedos que conversam com o mundo dele. 🧩</p>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-shadow border-l-4 border-[#FBA25C] sm:col-span-2 lg:col-span-1">
                  <div className="text-4xl mb-4 text-center">💙</div>
                  <h3 className="text-xl font-semibold text-[#FBA25C] mb-3 text-center">Curadoria Especializada</h3>
                  <p className="text-gray-600 text-sm leading-relaxed text-center">Todos os produtos são selecionados por especialistas em desenvolvimento infantil, pensados especialmente para crianças neurodivergentes.</p>
                </div>
              </div>
            </div>
          </section>

          {/* Collection Images */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 mb-12 w-full">
            <h2 className="text-[#0A3D2F] text-2xl sm:text-3xl md:text-4xl font-light text-center mb-8 sm:mb-12 tracking-wide">Brinquedos que Transformam o Brincar em Desenvolvimento</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              <Link to="/collections/apoio-aos-pais" className="group relative h-64 sm:h-72 md:h-80 overflow-hidden rounded-[10px] shadow-lg hover:shadow-2xl transition-shadow">
                <img src="https://cdn.shopify.com/s/files/1/0973/7116/0942/files/generated_image_21fe3c7e-31ac-462f-bc03-2914b30e0a54.png?v=1769916787" alt="Apoio aos Pais" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" loading="lazy" width="600" height="800"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A3D2F]/90 via-transparent to-transparent"></div>
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
                  <h3 className="text-white text-xl sm:text-2xl font-light tracking-wider mb-2 text-center">Apoio aos Pais</h3>
                  <span className="text-[#D4AF69] text-xs sm:text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">SHOP NOW →</span>
                </div>
              </Link>
              <Link to="/collections/por-idade" className="group relative h-64 sm:h-72 md:h-80 overflow-hidden rounded-[10px] shadow-lg hover:shadow-2xl transition-shadow">
                <img src="https://cdn.shopify.com/s/files/1/0973/7116/0942/files/generated_image_d44dd0bc-0ee2-424f-bef3-de0c883a2ad4.png?v=1769917212" alt="Por Idade" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" loading="lazy" width="600" height="800"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A3D2F]/90 via-transparent to-transparent"></div>
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
                  <h3 className="text-white text-xl sm:text-2xl font-light tracking-wider mb-2 text-center">Por Idade</h3>
                  <span className="text-[#D4AF69] text-xs sm:text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">SHOP NOW →</span>
                </div>
              </Link>
              <Link to="/collections/por-necessidade" className="group relative h-64 sm:h-72 md:h-80 overflow-hidden rounded-[10px] shadow-lg hover:shadow-2xl transition-shadow sm:col-span-2 lg:col-span-1">
                <img src="https://cdn.shopify.com/s/files/1/0973/7116/0942/files/generated_image_f119b9e6-82c2-415c-b716-7ea8abe4aecc.png?v=1769917448" alt="Por Necessidade" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" loading="lazy" width="600" height="800"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A3D2F]/90 via-transparent to-transparent"></div>
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
                  <h3 className="text-white text-xl sm:text-2xl font-light tracking-wider mb-2 text-center">Por Necessidade</h3>
                  <span className="text-[#D4AF69] text-xs sm:text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">SHOP NOW →</span>
                </div>
              </Link>
            </div>
          </section>

          {/* Featured Products */}
          <section className="bg-white py-12 sm:py-16 md:py-20 mb-16 sm:mb-20 w-full">
            <div className="max-w-7xl mx-auto px-4 sm:px-6">
              <h2 className="text-[#0A3D2F] text-2xl sm:text-3xl md:text-4xl font-light text-center mb-8 sm:mb-12 tracking-wide">ESCOLHAS CONSCIENTES PARA O DESENVOLVIMENTO INFANTIL</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
                {products.nodes.slice(0, 8).map(p => (
                  <Link key={p.id} to={`/products/${p.handle}`} className="group">
                    <div className="relative aspect-square mb-3 sm:mb-4 overflow-hidden rounded-[10px] bg-[#FEFDF8] shadow-md sm:shadow-lg group-hover:shadow-xl transition-shadow">
                      {p.featuredImage && (
                        <Image data={p.featuredImage} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" sizes="(max-width: 640px) 50vw, (max-width: 1024px) 25vw, 20vw" aspectRatio="1/1" alt={p.featuredImage.altText || `${p.title} - Luxury Watch USA UK Canada Australia`} />
                      )}
                    </div>
                    <div className="text-center px-2">
                      <p className="text-[#D4AF69] text-xs tracking-widest mb-1 uppercase font-semibold line-clamp-1">{p.vendor || 'brinqueTEAando'}</p>
                      <h3 className="text-[#0A3D2F] font-light mb-2 hover:text-[#1a5757] transition-colors text-xs sm:text-sm line-clamp-2">{p.title}</h3>
                      <Money data={p.priceRange.minVariantPrice} className="text-[#2a2a2a] font-medium text-xs sm:text-sm"/>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        </div>

        {/* FOOTER CLEAN E CENTRALIZADO (Igual ao das páginas internas) */}
        <footer className="bg-[#FEFDF8] pt-20 pb-10 border-t-4 border-[#3A8ECD] w-full">
          <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-16 text-center">
             
             {footerMenu.items.map((group) => (
               <div key={group.id} className="flex flex-col items-center">
                  
                  {/* Título Clean */}
                  <h3 className="font-bold text-[#0A3D2F] text-lg tracking-widest uppercase mb-6 border-b-2 border-transparent hover:border-[#FB8A38] transition-all duration-300 pb-2 inline-block">
                    {group.title}
                  </h3>

                  {/* Lista Centralizada */}
                  <ul className="flex flex-col gap-4 text-sm text-gray-500 w-full">
                    {group.items.map((link) => (
                      <li key={link.id} className="w-full">
                        <Link 
                          to={link.url} 
                          className="hover:text-[#FB8A38] hover:font-medium transition-all duration-200 block py-1"
                        >
                          {link.title}
                        </Link>
                      </li>
                    ))}
                  </ul>
               </div>
             ))}

          </div>

          {/* Copyright Centralizado */}
          <div className="max-w-7xl mx-auto px-6 pt-8 border-t border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-400">
              <p className="text-center md:text-left">&copy; {new Date().getFullYear()} brinqueTEAndo. Todos os direitos reservados.</p>
              <div className="flex gap-6 justify-center">
                <span className="cursor-pointer hover:text-[#3A8ECD] transition-colors">Privacidade</span>
                <span className="cursor-pointer hover:text-[#3A8ECD] transition-colors">Termos de Uso</span>
              </div>
          </div>
        </footer>
      </main>

      <QuickView product={quickViewProduct} isOpen={!!quickViewProduct} onClose={() => setQuickViewProduct(null)} />
    </>
  );
}

const FEATURED_COLLECTIONS_QUERY = '#graphql' + String.raw`
  fragment Collection on Collection {
    id
    title
    handle
    image {
      id
      url
      altText
      width
      height
    }
  }
  query FeaturedCollections(
    $country: CountryCode
    $language: LanguageCode
  ) @inContext(country: $country, language: $language) {
    collections(first: 4, sortKey: UPDATED_AT, reverse: true) {
      nodes {
        ...Collection
      }
    }
  }
`;

const FEATURED_PRODUCTS_QUERY = '#graphql' + String.raw`
  fragment MoneyProductItem on MoneyV2 {
    amount
    currencyCode
  }
  fragment ProductItem on Product {
    id
    handle
    title
    vendor
    featuredImage {
      id
      altText
      url
      width
      height
    }
    priceRange {
      minVariantPrice {
        ...MoneyProductItem
      }
    }
  }
  query FeaturedProducts(
    $country: CountryCode
    $language: LanguageCode
  ) @inContext(country: $country, language: $language) {
    products(first: 8, sortKey: UPDATED_AT, reverse: true) {
      nodes {
        ...ProductItem
      }
    }
  }
`;

const FOOTER_MENU_QUERY = `#graphql
  fragment MenuItem on MenuItem {
    id
    title
    url
    type
    items {
      id
      title
      url
      type
    }
  }
  query FooterMenu($footerMenuHandle: String!) {
    menu(handle: $footerMenuHandle) {
      id
      items {
        ...MenuItem
      }
    }
  }
`;